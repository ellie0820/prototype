var gulp = require('gulp');

var browserSync = require('browser-sync');
var notify = require('gulp-notify');
var plumber = require('gulp-plumber');
var runSequence = require('run-sequence');
//build:CSS
var pleeease = require('gulp-pleeease');
var sass = require('gulp-sass');
var sourcemaps = require("gulp-sourcemaps");
//build:IMGS
var imageMin = require('gulp-imagemin');
var pngquant = require('imagemin-pngquant');

var connectPHP = require('gulp-connect-php');

//browser-sync
gulp.task('connectPHP', function() {
  connectPHP.server({
    port: 3001,
    base: 'htdocs'
  }, function(){
    browserSync({
      proxy: 'localhost:3001'
    })
  });
});

gulp.task('browserSync:reload', function() {
  browserSync.reload();
  notify('Browser Reloaded');
});

//built HTML
gulp.task('build:html', function() {
  gulp.src('_htdocs/**/*.php')
    .pipe(gulp.dest('htdocs'));
});

gulp.task('reload:html', function() {
  return runSequence(
    'build:html',
    'browserSync:reload'
  );
});
////////////////////////////////////////////////////////////////////////////////

//built CSS
gulp.task('build:css', function() {
  gulp.src('_htdocs/css/*.scss')
    .pipe(plumber({
      errorHandler: notify.onError('Error on <gulp sass>: <%= error.message %>')
    }))
    .pipe(sourcemaps.init())
    .pipe(sass())
    .pipe(pleeease({
      autoprefixer: {
        browsers: ['iOS 7', 'Android 4.0', 'last 2 versions']
      },
      opacity: true,
      minifier: true
    }))
    .pipe(sourcemaps.write('./'))
    .pipe(notify('Complete <gulp sass>'))
    .pipe(gulp.dest('htdocs/css'));
});

////////////////////////////////////////////////////////////////////////////////

//built IMGS
gulp.task('build:imgs', function() {
  gulp.src('_htdocs/imgs/*').pipe(imageMin([pngquant({
    quality: '70'
  })])).pipe(gulp.dest('htdocs/imgs'));
});

gulp.task('reload:imgs', function() {
  return runSequence(
    'build:imgs',
    'browserSync:reload'
  );
});
////////////////////////////////////////////////////////////////////////////////

//built JS
gulp.task('build:js', function() {
  gulp.src('_htdocs/js/*.js')
    .pipe(gulp.dest('htdocs/js'));
});

gulp.task('reload:js', function() {
  return runSequence(
    'build:js',
    'browserSync:reload'
  );
});
////////////////////////////////////////////////////////////////////////////////

//watch
gulp.task('watch', function() {
  gulp.watch('_htdocs/**/*.php', ['reload:html']);
  gulp.watch('_htdocs/css/*.scss', ['build:css']);
  gulp.watch('htdocs/css/*.css', ['browserSync:reload']);
  gulp.watch('_htdocs/imgs/*', ['reload:imgs']);
  gulp.watch('_htdocs/js/*.js', ['reload:js']);
});
////////////////////////////////////////////////////////////////////////////////

//default
gulp.task('default', function() {
  return runSequence(
    ['build:html', 'build:css', 'build:imgs', 'build:js'],
    'connectPHP',
    'watch'
  );
});
