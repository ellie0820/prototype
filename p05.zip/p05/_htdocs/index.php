<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <title>Document</title>
</head>

<body>
  <header class="header--default">
    <h1 class="header--default__logo">elLie's</h1>
    <!--#include virtual="/nav.html" -->
    <div class="nav--global">
      <div class="nav--global__head js-nav--global__head">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <nav class="nav--global__body js-nav--global__body">
        <ul>
          <li><a href="index.html">coding guidelines</a></li>
          <li><a href="amp.html">amp</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main class="main--default">
    <article class="article--default">
      <h1 class="article--default__head">coding guidelines</h1>

      <section class="section--default" id="structure">
        <h2 class="section--default__head">structure</h2>
        <div class="section--default__body">
          <ul>
            <li><span class="fc-emphasis fw-bold">header</span>
              <ul class="list-indent--primary">
                <li><span class="fc-emphasis fw-bold">h1</span>{logo}</li>
              </ul>
            </li>
            <li><span class="fc-emphasis fw-bold">nav</span>.nav--global</li>
            <li><span class="fc-emphasis fw-bold">main</span>
              <ul class="list-indent--primary">
                <li><span class="fc-emphasis fw-bold">article</span>
                  <ul class="list-indent--primary">
                    <li><span class="fc-emphasis fw-bold">ul</span>.breadcrumb</li>
                    <li><span class="fc-emphasis fw-bold">h1</span>.hero / <span class="fc-emphasis fw-bold">h1</span>.jumbotron</li>
                    <li><span class="fc-emphasis fw-bold">section</span>
                      <ul class="list-indent--primary">
                        <li><span class="fc-emphasis fw-bold">section</span>.panel / <span class="fc-emphasis fw-bold">section</span>.tile
                          <ul class="list-indent--primary">
                            <li><span class="fc-emphasis fw-bold">div</span>.definition</li>
                            <li><span class="fc-emphasis fw-bold">div</span>.card</li>
                            <li><span class="fc-emphasis fw-bold">div</span>.media</li>
                          </ul>
                        </li>
                        <li><span class="fc-emphasis fw-bold">div</span>.well</li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li><span class="fc-emphasis fw-bold">aside</span></li>
              </ul>
            </li>
            <li><span class="fc-emphasis fw-bold">footer</span></li>
          </ul>
        </div>
      </section>

      <section class="section--default" id="order">
        <h2 class="section--default__head">order &amp; rules</h2>
        <div class="section--default__body">
          <table class="table--default mb-s">
            <colgroup span="4" width="25%"></colgroup>
            <tr>
              <th>1st</th>
              <th>2nd</th>
              <th>3rd</th>
              <th>4th</th>
            </tr>
            <tr>
              <td>header<br>nav<br>footer<br>aside<br>main<br>article<br>section<br>panel / tile<br>definition<br>card / feature<br>media<br>etc...</td>
              <td>--default<br>--primary<br>--secondary<br>--global<br>--local</td>
              <td>__head<br>__body<br>__upper<br>__lower<br>__nav<br>__sitemap<br>__logo{logo}</td>
              <td>--logo<br>--editing<br>--nav<br>--sitemap<br>--figure<br>--editing</td>
            </tr>
          </table>
          <section class="panel--default" id="o-header">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">header</span>.header--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">header</span>でマークアップすること</li>
                <li>・<span class="fc-emphasis fw-bold">header</span>の中に含まれるロゴについては原則として<span class="fc-emphasis fw-bold">h1.header--hoge__logo{logo}</span>としてマークアップすること</li>
                <li>・基本的に<span class="fc-emphasis fw-bold">header</span>の中に<span class="fc-emphasis fw-bold">nav.nav--global</span>は含めないこと</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-nav">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">nav</span>.nav--global</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">nav</span>でマークアップすること</li>
                <li>・基本的に<span class="fc-emphasis fw-bold">header</span>や<span class="fc-emphasis fw-bold">article</span>の中に含めないこと</li>
                <li>・その他のナビゲーションについては、その親要素を基準にネストし、<span class="fc-emphasis fw-bold">ul</span>でマークアップすること
                  <br>example. <span class="fc-emphasis fw-bold">ul.footer--hoge__nav</span></li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-footer">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">footer</span>.footer--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">footer</span>でマークアップすること</li>
                <li>・基本的にコピーライトについては、<span class="fc-emphasis fw-bold">p.footer--hoge__copyright{&copy; copyright}</span></li>
                <li>・サイトマップもしくはナビゲーションについては、<span class="fc-emphasis fw-bold">ul.footer--hoge__sitemap</span>もしくは<span class="fc-emphasis fw-bold">ul.footer--hoge__nav</span>でマークアップすること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-main">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">main</span>.main--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">main</span>でマークアップすること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-aside">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">aside</span>.aside--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">aside</span>でマークアップすること</li>
                <li>・原則としてバナーや関連記事などに用いること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-article">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">article</span>.article--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">article</span>でマークアップすること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-section">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">section</span>.section--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">section</span>でマークアップすること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-panel">
            <h3 class="panel--default__head"><span class="fc-emphasis fw-bold">section</span>.panel--hoge / <span class="fc-emphasis fw-bold">section</span>.tile--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default">
                <li>・原則として<span class="fc-emphasis fw-bold">section</span>でマークアップすること</li>
                <li>・基本的に<span class="fc-emphasis fw-bold">section</span>.section--hogeの中で使用すること</li>
                <li>・原則として<span class="fc-emphasis fw-bold">section</span>.panel--hogeを優先的に使用すること</li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-definition">
            <h3 class="panel--default__head">.definition--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default mb-s">
                <li>・タイトル＋コンテンツがテキストのみで一組になっているものに使用すること</li>
                <li>・複数横並びになっている場合は、.definition-group--defaultとして利用
                  <ul class="list-indent--default">
                    <li>※.definition-group--defaultにてマークアップする際は、原則として<span class="fc-emphasis fw-bold">ul</span>を使用</li>
                  </ul>
                </li>
              </ul>
              <dl class="definition--default mb-s">
                <dt class="definition--default__head">Lorem ipsum dolor.</dt>
                <dd class="definition--default__body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos reiciendis nam excepturi consequatur dignissimos iusto nobis soluta quaerat labore. Enim!</dd>
              </dl>
              <ul class="definition-group--default">
                <li>
                  <div class="definition--default">
                    <p class="definition--default__head">Lorem ipsum dolor.</p>
                    <p class="definition--default__body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                  </div>
                </li>
                <li>
                  <div class="definition--default">
                    <p class="definition--default__head">Lorem ipsum dolor.</p>
                    <p class="definition--default__body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                  </div>
                </li>
                <li>
                  <div class="definition--default">
                    <p class="definition--default__head">Lorem ipsum dolor.</p>
                    <p class="definition--default__body">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                  </div>
                </li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-card">
            <h3 class="panel--default__head">.card--hoge / .feature--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default mb-s">
                <li>・画像＋コンテンツが縦並びの構成で一組になっているものに使用</li>
                <li>・card--defaultを優先的に利用に使用すること</li>
                <li>・複数横並びになっている場合は、.card-group--defaultとして利用
                  <ul class="list-indent--default">
                    <li>※.card-group--defaultにてマークアップする際は、原則として<span class="fc-emphasis fw-bold">ul</span>を使用</li>
                  </ul>
                </li>
              </ul>
              <dl class="card--default mb-s">
                <dt class="card--default__head">Lorem ipsum dolor.</dt>
                <dd class="card--default__body">
                  <figure class="card--default__body--figure"><img src="imgs/img.png" alt=""></figure>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos reiciendis nam excepturi consequatur dignissimos iusto nobis soluta quaerat labore. Enim!</dd>
              </dl>
              <ul class="card-group--default">
                <li>
                  <div class="card--default">
                    <p class="card--default__head">Lorem ipsum dolor.</p>
                    <div class="card--default__body">
                      <figure class="card--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card--default">
                    <p class="card--default__head">Lorem ipsum dolor.</p>
                    <div class="card--default__body">
                      <figure class="card--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="card--default">
                    <p class="card--default__head">Lorem ipsum dolor.</p>
                    <div class="card--default__body">
                      <figure class="card--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, fuga.</p>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-media">
            <h3 class="panel--default__head">.media--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default mb-s">
                <li>・画像＋コンテンツが横並びの構成で一組になっているものに使用 </li>
                <li>・複数横並びになっている場合は、.media-group--defaultとして利用
                  <ul class="list-indent--default">
                    <li>※.media-group--defaultにてマークアップする際は、原則として<span class="fc-emphasis fw-bold">ul</span>を使用</li>
                  </ul>
                </li>
              </ul>
              <dl class="media--default mb-s">
                <dt class="media--default__head">Lorem ipsum dolor.</dt>
                <dd class="media--default__body">
                  <figure class="media--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                  <div class="media--default__body--editing">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos reiciendis nam excepturi consequatur dignissimos iusto nobis soluta quaerat labore. Enim!</div>
                </dd>
              </dl>
              <ul class="media-group--default">
                <li>
                  <div class="media--default">
                    <p class="media--default__head">Lorem ipsum dolor.</p>
                    <div class="media--default__body">
                      <figure class="media--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                      <div class="media--default__body--editing">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fuga, eaque.</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div class="media--default">
                    <p class="media--default__head">Lorem ipsum dolor.ß</p>
                    <div class="media--default__body">
                      <figure class="media--default__body--figure"><img src="imgs/img.png" alt=""></figure>
                      <div class="media--default__body--editing">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Odio, omnis.</div>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </section>

          <section class="panel--default" id="o-well">
            <h3 class="panel--default__head">.well--hoge</h3>
            <div class="panel--default__body">
              <ul class="list-indent--default mb-s">
                <li>・タイトルなどがない注釈などに使用すること</li>
                <li>・複数横並びになっている場合は、.well-group--defaultとして利用
                  <ul class="list-indent--default">
                    <li>※.well-group--defaultにてマークアップする際は、原則として<span class="fc-emphasis fw-bold">ul</span>を使用</li>
                  </ul>
                </li>
              </ul>
              <div class="well--default">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.<br>Necessitatibus est, ut atque, veritatis amet quibusdam impedit? Eos obcaecati, dolorem optio!</p>
              </div>
            </div>
          </section>

          <section class="panel--default">
            <h3 class="panel--default__head">frame | 骨組み</h3>
            <div class="panel--default__body">
              <ul class="mb-s">
                <li><span class="fc-emphasis fw-bold">main</span>.main--hoge</li>
                <li><span class="fc-emphasis fw-bold">aside</span>.aside--hoge</li>
                <li><span class="fc-emphasis fw-bold">article</span>.article--hoge</li>
                <li><span class="fc-emphasis fw-bold">section</span>.section--hoge</li>
                <li><span class="fc-emphasis fw-bold">section</span>.pnael--hoge / <span class="fc-emphasis fw-bold">section</span>tile--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.definition--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.card--hoge / <span class="fc-emphasis fw-bold">div</span>.feature--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.media--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.figure--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.well--hoge</li>
                <li><span class="fc-emphasis fw-bold">div</span>.columnXX--hoge</li>
              </ul>

              <dl class="definition--default">
                <dt class="definition--default__head">javascript</dt>
                <dd class="definition--default__body">
                  <ul>
                    <li>.accordion--hoge</li>
                    <li>.pulldown--hoge</li>
                    <li>.slider--hoge</li>
                    <li>.tab--hoge</li>
                  </ul>
                </dd>
              </dl>
            </div>
          </section>

        </div>
      </section>

      <section class="section--default">
        <h1 class="section--default__head">heading</h1>
        <div class="section--default__body">
          <h1 class="article--default__head mb-s"><strong class="fc-emphasis fw-bold">class="article--default__head"</strong><br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Qui, nam.</h1>
          <table class="table--default mb-l">
            <colgroup span="4" width="25%"></colgroup>
            <tr>
              <th></th>
              <th>$type==cmn</th>
              <th>$type==rsp</th>
              <th>$type==mb</th>
            </tr>
            <tr>
              <th>font-size</th>
              <td>4.8rem</td>
              <td></td>
              <td>3.2rem<br>32/320*100vw</td>
            </tr>
            <tr>
              <th>margin-bottom</th>
              <td>80px</td>
              <td></td>
              <td>40px</td>
            </tr>
          </table>
          <h1 class="section--default__head mb-s"><strong class="fc-emphasis fw-bold">class="section--default__head"</strong><br>Dolorem itaque nobis inventore dicta dolorum molestiae et aut, eveniet.</h1>
          <table class="table--default mb-l">
            <colgroup span="4" width="25%"></colgroup>
            <tr>
              <th></th>
              <th>$type==cmn</th>
              <th>$type==rsp</th>
              <th>$type==mb</th>
            </tr>
            <tr>
              <th>font-size</th>
              <td>4.0rem</td>
              <td></td>
              <td>2.8rem<br>28/320*100vw</td>
            </tr>
            <tr>
              <th>margin-bottom</th>
              <td>60px</td>
              <td></td>
              <td>30px</td>
            </tr>
          </table>
          <h1 class="panel--default__head mb-s"><strong class="fc-emphasis fw-bold">class="panel--default__head"</strong><br>Inventore doloremque aspernatur ea, eligendi non accusantium. Omnis, magnam, sunt?</h1>
          <table class="table--default mb-l">
            <colgroup span="4" width="25%"></colgroup>
            <tr>
              <th></th>
              <th>$type==cmn</th>
              <th>$type==rsp</th>
              <th>$type==mb</th>
            </tr>
            <tr>
              <th>font-size</th>
              <td>3.2rem</td>
              <td></td>
              <td>2.4rem<br>24/320*100vw</td>
            </tr>
            <tr>
              <th>margin-bottom</th>
              <td>40px</td>
              <td></td>
              <td>20px</td>
            </tr>
          </table>
          <h1 class="heading--default mb-s"><strong class="fc-emphasis">class="heading--default"</strong><br>Ipsum commodi, adipisci, nesciunt labore cum quibusdam quasi voluptatem similique!</h1>
          <table class="table--default">
            <colgroup span="4" width="25%"></colgroup>
            <tr>
              <th></th>
              <th>$type==cmn</th>
              <th>$type==rsp</th>
              <th>$type==mb</th>
            </tr>
            <tr>
              <th>font-size</th>
              <td>2.4rem</td>
              <td></td>
              <td>2.0rem<br>20/320*100vw</td>
            </tr>
            <tr>
              <th>margin-bottom</th>
              <td>20px</td>
              <td></td>
              <td>10px</td>
            </tr>
          </table>
        </div>
      </section>
    </article>

    <div class="nav--local">
      <ul>
        <li><a href="#structure">structure</a></li>
        <li><a href="#order">order</a></li>
        <li><a href="#rules">rules</a>
          <ul class="list-indent--primary">
            <li><a href="#o-header">header</a></li>
            <li><a href="#o-nav">nav</a></li>
            <li><a href="#o-footer">footer</a></li>
            <li><a href="#o-main">main</a></li>
            <li><a href="#o-aside">aside</a></li>
            <li><a href="#o-article">article</a></li>
            <li><a href="#o-section">section</a></li>
            <li><a href="#o-pnael">pnael / tile</a></li>
            <li><a href="#o-definition">definition</a></li>
            <li><a href="#o-card">card / feature</a></li>
            <li><a href="#o-media">media</a></li>
            <li><a href="#o-figure">figure</a></li>
            <li><a href="#o-well">well</a></li>
            <li><a href="#o-column">column</a></li>
            <li><a href="#o-accordion">accordion</a></li>
            <li><a href="#o-pulldown">pulldown</a></li>
            <li><a href="#o-slider">slider</a></li>
            <li><a href="#o-tab">tab</a></li>
            <li><a href="#o-breadcrumb">breadcrumb</a></li>
            <li><a href="#o-bar">bar</a></li>
            <li><a href="#o-hero">hero / jumbotron</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </main>
  <div class="overlay"></div>
  <!--script type="text/javascript" src="//code.jquery.com/jquery-1.11.3.js"></script-->
  <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
  <script type="text/javascript" src="js/style.js"></script>
</body>

</html>
