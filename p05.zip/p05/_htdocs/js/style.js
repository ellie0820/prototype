var $overlay = $('.overlay');

var $navGlobalHead = $('.js-nav--global__head');
var $navGlobalBody = $('.js-nav--global__body');

$navGlobalHead.on('click', function() {
  $(this).toggleClass('active');
  $navGlobalBody.toggleClass('active');
  if ($(this).hasClass('active')) {
    $overlay.fadeIn();
  } else {
    $overlay.fadeOut();
  }
});

var $blockSrc = $('.js-block--source');
$blockSrc.each(function() {
  var blockSrcInput = $(this).find('.js-block--source__input').html();
  $(this).find('.js-block--source__output').text(blockSrcInput);
});
