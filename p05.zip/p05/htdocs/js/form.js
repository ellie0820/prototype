$(function() {
  //matchHeighte
  $('.column03--default > li').matchHeight();

  $nec = $('.js--base--necessary');
  $nec.each(function() {

    //select
    var $select = $(this).find('select');
    $select.change(function() {
      var i = 0;
      $select.each(function() {
        var val = $(this).children('option:selected').text();
        if (val == '選択してください') {
          i++;
        }
      });
      if (i == 0) {
        $(this).parents('.js--base--necessary').removeClass('base--necessary');
      } else {
        $(this).parents('.js--base--necessary').addClass('base--necessary');
      }
    });

    //text
    var $input = $(this).find('input');
    $input.on('blur', function() {
      var j = 0;
      $input.each(function() {
        var inputVal = $(this).val();
        if (inputVal == '') {
          j++;
        }
      });
      if (j == 0) {
        $(this).parents('.js--base--necessary').removeClass('base--necessary');
      } else {
        $(this).parents('.js--base--necessary').addClass('base--necessary');
      }
    });

    //checkbox
    $check = $(this).find('.js--check');
    $check.click(function() {
      var k = $(this).children('input[type="checkbox"]:checked').length;
      if (k > 0) {
        $(this).parents('.js--base--necessary').removeClass('base--necessary');
      } else {
        $(this).parents('.js--base--necessary').addClass('base--necessary');
      }
    });

    //input type="radio"
    $radio = $('.js--radio input[type="radio"]');
    $radio.on('change', function() {
      if ($(this).prop('checked')) {
        $(this).parents('.js--base--necessary').removeClass('base--necessary');
      } else {
        $(this).parents('.js--base--necessary').addClass('base--necessary');
      }
    });

  });



  //mail
  var $inputMail = $('.js--input--mail');
  $inputMail.on('keyup', function() {
    var mail = $(this).val();
    $('.block--mail__body').html(mail);
    var countM = mail.length;
    if (countM == '0') {
      $('.block--mail__body').html('test@example.com');
    }
  });

  var $btnSbumit = $('.js--btn--submit');
  var $error = $('.wrapper .well--error');
  var $necessary = $('.wrapper .base--necessary');
  $btnSbumit.on('click', function() {
    $error.css('display', 'block');
    $necessary.addClass('base--error');

    var position = $('#error').offset().top;
    $('body,html').animate({
      scrollTop: position
    }, 'swing');
    return false;
  });




});
